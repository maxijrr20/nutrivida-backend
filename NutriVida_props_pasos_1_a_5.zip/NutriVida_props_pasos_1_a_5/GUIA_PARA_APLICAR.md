# Guía para aplicar la corrección de props en NutriVida

La corrección está dividida en **5 pasos**, uno por commit, todos a nombre de **Maximiliano**.
**Hay que aplicarlos en orden**, porque cada paso parte de lo que dejó el anterior.

> Los parches parten del `main` actual de GitHub (último commit `33c880c docs: agrega enlace a repositorio backend y checklist de avance`). Si alguien sube otros cambios a `main` antes de aplicarlos, puede que dejen de calzar.

**Qué se corrige:** varios organismos y moléculas buscaban sus propios datos (contextos, archivos JSON, datos escritos adentro) y usaban el router (`useNavigate`, `Link`) directamente. Ahora **las páginas obtienen los datos y las acciones y se las entregan por props**. Los componentes de abajo solo muestran lo que reciben y avisan con funciones (`onAgendar`, `onVerDetalle`, `onEnviar`...), como piden las guías 11, 12 y 14. Además, los nombres de las props quedan **todos en español** (`titulo`, `descripcion`, `precio`, `valor`, `etiqueta`).

| # | Commit (texto en `MENSAJE_COMMIT.txt`) | Archivos | Qué incluye |
|---|---|---|---|
| 1 | `refactor: el inicio entrega datos y acciones por props…` | 9 | `HomePage` entrega datos y acciones a `HeroSection`, `BenefitsSection`, `FeaturedServicesSection` y `ClinicInfoSection`. `BenefitsSection` ahora usa la molécula `BenefitCard`. Datos del inicio en `src/data/inicio.js`. **Corrige un error:** los servicios destacados mostraban "Consultar" en vez del precio (`Price` recibía `value` y espera `valor`). |
| 2 | `refactor: ServiciosPage entrega los servicios…` | 3 | `ServiciosPage` le pasa los servicios al catálogo. `ServiceCard` ya no importa `Link`: recibe `onVerDetalle` y `onAgendar`. |
| 3 | `refactor: TeamDirectorySection recibe nutricionistas…` | 3 | El directorio recibe la lista de nutricionistas y `onAgendar` por props. `NutritionistRow` recibe cada dato por separado. **Corrige un error:** el botón "Agendar" era `<a href="/contacto">`, que en GitHub Pages llevaba a una dirección sin `/NutriVidaProyecto` y recargaba la página. |
| 4 | `refactor: AppointmentFormSection recibe datos y onEnviar…` | 4 | El formulario recibe `servicios`, `nutricionistas`, `datosIniciales` y `onEnviar`. `ContactoPage` lee la sesión, guarda la cita (`useCitas`) y navega a la confirmación. Las 2 pruebas que ya existían (del formulario y de la página) se adaptan a la nueva estructura; no se agregan pruebas nuevas. |
| 5 | `refactor: las páginas usan el átomo Button…` | 5 | Las 4 páginas que usaban el `Button` de React Bootstrap ahora usan el átomo `atoms/Button`, que reenvía props extra (`as`, `to`, `style`). **Corrige:** en `DetalleServicioPage` había un botón dentro de un enlace (HTML inválido). |

**Verificado antes de entregar:** en una copia limpia de GitHub se aplicaron los 5 parches en orden con `git apply`, y después pasan las **14 pruebas** que ya tenía el proyecto (no se agregaron pruebas nuevas), `npm run build` funciona y el lint no tiene avisos nuevos. También se revisó en el navegador: inicio, catálogo, detalle, directorio y formulario.

## Cómo aplicar los pasos (desde tu terminal, con tu cuenta)

Abre una terminal **en la carpeta del repositorio** (la que tiene `README.md` y la carpeta `nutrivida`). Descomprime este zip en una carpeta fuera del repositorio, por ejemplo `C:\Users\<tu usuario>\Downloads\NutriVida_props_pasos_1_a_5`.

### 1. Preparar una rama

```bash
git checkout main
git pull
git status
```

`git status` debe decir que no hay cambios pendientes. Luego crea la rama:

```bash
git checkout -b refactor/props
```

### 2. Aplicar cada paso y hacer su commit (repetir del 1 al 5, en orden)

Reemplaza `RUTA` por la carpeta donde descomprimiste el zip. Ejemplo para el **paso 1**:

```bash
git apply --ignore-whitespace "RUTA/pasos/1_Maximiliano_props-inicio/1_Maximiliano_props-inicio.patch"
git add -A
git commit -F "RUTA/pasos/1_Maximiliano_props-inicio/MENSAJE_COMMIT.txt"
```

`git commit -F` toma el mensaje desde el archivo, así no hay que copiarlo a mano. El commit queda con **tu nombre y tu correo de Git** (los de `git config user.name` y `git config user.email`).

Los cinco pasos, uno tras otro:

```bash
git apply --ignore-whitespace "RUTA/pasos/1_Maximiliano_props-inicio/1_Maximiliano_props-inicio.patch"
git add -A
git commit -F "RUTA/pasos/1_Maximiliano_props-inicio/MENSAJE_COMMIT.txt"

git apply --ignore-whitespace "RUTA/pasos/2_Maximiliano_props-catalogo/2_Maximiliano_props-catalogo.patch"
git add -A
git commit -F "RUTA/pasos/2_Maximiliano_props-catalogo/MENSAJE_COMMIT.txt"

git apply --ignore-whitespace "RUTA/pasos/3_Maximiliano_props-equipo/3_Maximiliano_props-equipo.patch"
git add -A
git commit -F "RUTA/pasos/3_Maximiliano_props-equipo/MENSAJE_COMMIT.txt"

git apply --ignore-whitespace "RUTA/pasos/4_Maximiliano_props-formulario-citas/4_Maximiliano_props-formulario-citas.patch"
git add -A
git commit -F "RUTA/pasos/4_Maximiliano_props-formulario-citas/MENSAJE_COMMIT.txt"

git apply --ignore-whitespace "RUTA/pasos/5_Maximiliano_atomo-button/5_Maximiliano_atomo-button.patch"
git add -A
git commit -F "RUTA/pasos/5_Maximiliano_atomo-button/MENSAJE_COMMIT.txt"
```

### 3. Comprobar antes de subir

```bash
cd nutrivida
npm install
npm run test:run
npm run build
npm run dev
cd ..
```

Deben pasar **14 pruebas**. Con `npm run dev` revisa el inicio, `Servicios y Equipo`, el detalle de un servicio y `Agendar Cita`.

### 4. Subir y crear el Pull Request

```bash
git push -u origin refactor/props
```

Luego, en GitHub, crea el **Pull Request** de `refactor/props` hacia `main` y haz el *merge*. Si prefieres subir directo a `main` sin PR: `git checkout main`, `git merge refactor/props` y `git push`.

### Si `git apply` falla en algún paso

Cada paso trae la carpeta `archivos/` con los archivos completos de ese paso:
1. Copia el contenido de `archivos/` sobre la raíz del repositorio (reemplazando).
2. Borra los archivos que aparezcan en `ELIMINAR.txt` (en estos 5 pasos está vacío: no se borra nada).
3. `git add -A` y `git commit -F` con el `MENSAJE_COMMIT.txt` de ese paso.

## Para la defensa: qué explicar de cada paso

**La idea general (guías 11, 12 y 14)**
- Las props viajan **de padre a hijo**. Ahora el recorrido se lee de arriba hacia abajo: **página → organismo → molécula → átomo**.
- **Solo las páginas** usan el router (`useNavigate`) y los contextos (`useServicios`, `useCitas`). Los organismos y moléculas reciben funciones por props (`onAgendar`, `onVerDetalle`, `onVerTodos`, `onEnviar`) y las llaman. Así no dependen del router y se pueden probar sin él (por ejemplo, la prueba del formulario ya no necesita `MemoryRouter` ni los Providers).
- Los organismos pueden tener **estado propio de la interfaz** (lo que el usuario escribe en un buscador o en un formulario), pero los **datos** les llegan por props.
- Las props usan nombres en español en todo el proyecto: `titulo`, `descripcion`, `precio`, `valor`, `etiqueta`.

**Paso 1 · Inicio**
- `HomePage` obtiene `navigate` y los servicios, filtra los destacados y entrega a cada organismo lo que necesita: `HeroSection` recibe `onAgendar` y `onVerServicios`; `BenefitsSection`, la lista `beneficios`; `FeaturedServicesSection`, `servicios` y `onVerTodos`; `ClinicInfoSection`, `datos`.
- `BenefitsSection` ya no dibuja las tarjetas a mano: usa la molécula `BenefitCard` (que existía pero no se usaba).
- El error del precio: `FeaturedServiceCard` le pasaba `value={price}` al átomo `Price`, pero el átomo espera `valor`. Como la prop no calzaba, siempre mostraba "Consultar". Es justo el tipo de error que aparece cuando los nombres de props no son consistentes.

**Paso 2 · Catálogo**
- `ServiciosPage` le pasa `servicios`, `onVerDetalle` y `onAgendar` a `ServicesCatalogSection`.
- El catálogo mantiene en su estado solo los filtros (categoría y texto) y le pasa a cada `ServiceCard` una función ya armada: `onVerDetalle={() => onVerDetalle(servicio.id)}`, igual que `onSeguir` en el ejemplo de la guía 12.

**Paso 3 · Equipo**
- `TeamDirectorySection` recibe `nutricionistas` y `onAgendar`; ya no importa el JSON.
- `NutritionistRow` recibe cada dato como prop (`codigo`, `nombre`, `especialidad`, `dias`, `horario`) en vez de un objeto completo, para que se vea qué usa.
- El botón "Agendar" era un `<a href="/contacto">`, que en GitHub Pages iba a una dirección sin `/NutriVidaProyecto` y recargaba toda la página. Ahora es un botón que llama a `onAgendar`, y la página navega con el router.

**Paso 4 · Formulario de citas**
- Reparto de la guía 14: el **formulario** (organismo) es dueño del estado y de los errores, y valida al enviar; la **página** (`ContactoPage`) decide qué pasa después de un envío correcto (guardar con `agregarCita` y navegar a la confirmación).
- El formulario recibe `servicios`, `nutricionistas`, `datosIniciales` (los datos de la sesión, que lee la página) y `onEnviar`. Si hay errores, `onEnviar` nunca se llama.
- Pruebas (las mismas que ya existían, adaptadas): la del formulario ahora comprueba que `onEnviar` se llama con los datos correctos, o que no se llama si hay errores; la de la página se envuelve en el router y los Providers porque ahora la página usa `useNavigate` y los contextos.

**Paso 5 · Átomo Button**
- Antes había dos botones distintos: el átomo `atoms/Button` y el `Button` de React Bootstrap importado directo en 4 páginas. Ahora todas usan el átomo.
- El átomo reenvía las props que no usa con `...resto` (por ejemplo `as={Link}`, `to`, `style`), así sirve como botón o como enlace.
- En `DetalleServicioPage` había un `<Button>` dentro de un `<Link>` (un botón dentro de un enlace, HTML inválido). Ahora es un solo elemento: `<Button as={Link} to="/servicios">`.

## Lo que quedó fuera (no es tema de props)
- La sesión se sigue leyendo desde `localStorage` en varios archivos (`NavbarNutriVida`, `LoginPage`, `RegistroPage`, `AdminDashboardPage`, `RutaAdmin`). Eso corresponde al tema de **hooks** (por ejemplo, un `useSesion`).
- `NavbarNutriVida` sigue usando `Link`/`NavLink`; es la barra de navegación y su uso del router es habitual.
- Las páginas grandes (`RegistroPage`, `SolicitudEnCursoPage`, `BlogPage`) siguen armando parte de su interfaz a mano.
